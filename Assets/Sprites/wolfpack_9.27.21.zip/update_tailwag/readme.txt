-=-=-=- -==-=- -==-=- -==-=- -==-=-
          The WOLF PACK - update
-==-=- -==-=- -==-=- -==-=- -==-=-

This is a small update that adds an extra animation, with the wolves sitting down wagging their tails.
- 3/5/2021

-------------------------

Special thanks to my patrons for making this possible. - patreon.com/finalbossblues

-------------------------
Time Fantasy Website
 timefantasy.net
-------------------------
Artist's Website
 finalbossblues.com
Twitter
 @finalbossblues
Patreon
 patreon.com/finalbossblues
-------------------------