-=-=-=- -==-=- -==-=- -==-=- -==-=-
          The WOLF PACK - down pose update
-==-=- -==-=- -==-=- -==-=- -==-=-

This is a small update that adds two extra frames for "down" poses. 

One of the poses is a frame that could work for a KO/dead pose or sleeping; while the other pose is the sleepy-dog curled position.

Note: The sprite sheet includes a grid of empty colored squares-- the purpose of these is to clarify the alignment of the sheet, so that users can more easily edit or re-organize the frames.

- 9/27/2021

-------------------------

Special thanks to my patrons for making this possible. - patreon.com/finalbossblues

-------------------------
Time Fantasy Website
 timefantasy.net
-------------------------
Artist's Website
 finalbossblues.com
Twitter
 @finalbossblues
Patreon
 patreon.com/finalbossblues
-------------------------